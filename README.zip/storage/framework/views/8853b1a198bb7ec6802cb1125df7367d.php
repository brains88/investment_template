<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div class="wrapper">
        <?php echo $__env->make('layout.adminnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

        <!-- transfer History -->
<section class="transaction-history pt-5 mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="header-text-full">
                    <h2>Users Transfer Log</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="table-parent table-responsive">
                    <table class="table table-striped mb-5">
                        <thead>
                            <tr>
                                <th scope="col">Sender</th>
                                <th scope="col">Receiver</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Status</th>
                                <th scope="col">Time</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                        <td><?php echo e($transfer->sender->name); ?></td>
                                        <td><?php echo e($transfer->receiver->name); ?></td>
                                        <td><?php echo e($transfer->amount); ?> USD</td>
                                        <td><?php echo e(ucfirst($transfer->status)); ?></td>
                                        <td><?php echo e($transfer->created_at->format('d M Y h:i A')); ?></td>
                                        <td>
                                            <button class="btn btn-danger delete-btn" data-id="<?php echo e($transfer->id); ?>" data-bs-toggle="modal" data-bs-target="#deleteModal">
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">No Transfer history for User.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="pagination-container">
                        <?php echo e($transfers->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

  
     <!-- Delete Confirmation Modal -->
     <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <form method="POST" action="" id="delete-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Are you sure you want to delete this transfer?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">
                                <span class="spinner-border spinner-border-sm d-none" role="status"></span>
                                Delete
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
  
</section>

    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const form = document.getElementById('delete-form');
            form.action = `<?php echo e(route('transfers.delete', '')); ?>/${id}`;
        });
    });

    document.querySelectorAll('form button[type="submit"]').forEach(button => {
    button.addEventListener('click', function () {
        const spinner = this.querySelector('.spinner-border');
        if (spinner) {
            spinner.classList.remove('d-none');
        }
    });
});

</script>

</body>
<?php /**PATH C:\xampp\htdocs\equity\resources\views\admin\transfer.blade.php ENDPATH**/ ?>