<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Header Component -->

<body>
<div class="wrapper">
<?php echo $__env->make('layout.usernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- User Navbar -->
<!------------- others main dashboard body content ------------>

<!-- Fund history -->
<section class="transaction-history mt-5 pt-5">
<div class="container-fluid">
<div class="row">
<div class="col">
<div class="header-text-full">
<h2>Fund History</h2>
</div>
</div>
</div>

<div class="row">
<div class="col">
<div class="table-parent table-responsive">
<table class="table table-striped mb-5">
<thead>
<tr>
<th scope="col">Transaction ID</th>
<th scope="col">Gateway</th>
<th scope="col">Amount</th>
<th scope="col">Status</th>
<th scope="col">Time</th>
</tr>
</thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td><?php echo e($deposit->transaction_number); ?></td>
<td><?php echo e($deposit->wallet->coin); ?> - <?php echo e($deposit->wallet->network); ?></td>
<td><?php echo e($deposit->amount); ?> USD</td>
<td>
<?php if($deposit->status === 'completed'): ?>
<span class="badge bg-success">Complete</span>
<?php elseif($deposit->status === 'pending'): ?>
<span class="badge bg-warning">Pending</span>
<?php else: ?>
<span class="badge bg-danger">Cancelled</span>
<?php endif; ?>
</td>
<td><?php echo e($deposit->created_at->diffForHumans()); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
<td colspan="5" class="text-center">No deposit history available.</td>
</tr>
<?php endif; ?>
</tbody>
</table>
<!-- Pagination -->
<div class="pagination-container">
<?php echo e($deposits->links('pagination::bootstrap-4')); ?>

</div>

</div>
</div>
</div>
</div>
</section>


</div>
</div>
</div>


<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
</body>
</html>
<?php /**PATH C:\xampp\htdocs\equity\resources\views\user\fund-history.blade.php ENDPATH**/ ?>