<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Header Component -->

<body>
<div class="wrapper">
<?php echo $__env->make('layout.usernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- User Navbar -->

    <!------------- others main dashboard body content ------------>
    <section class="transaction-history mt-5 pt-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <div class="header-text-full">
                        <h2>Transaction</h2>
                    </div>
                </div>
            </div>

            <form action="https://www.equitytradeslc.com/user/transaction-search" method="get">
                <div class="row select-transaction">
                    <!-- Search form (same as your code) -->
                </div>
            </form>

            <div class="row">
                <div class="col">
                    <div class="table-parent table-responsive">
                            <table class="table table-striped mb-5">
                                <thead>
                                    <tr>
                                        <th>SL No.</th>
                                        <th>Transaction ID</th>
                                        <th>Amount</th>
                                        <th>Remarks</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                      <!-- Display alert if there are no transactions -->
                                    <?php if($transactions->isEmpty()): ?>
                                    <tr>
                                        <td colspan="5" class="text-center mt-3" class="alert alert-warning" role="alert">
                                            No transactions found.
                                    </td>
                                    </tr>
                                    <?php else: ?>
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($transaction->transaction_id); ?></td>
                                        <td>
                                            <?php if($transaction->sender_id == auth()->id()): ?>
                                                <span class="fontBold text-danger">-<?php echo e($transaction->amount); ?> USD</span> <!-- Withdrawal -->
                                            <?php else: ?>
                                                <span class="fontBold text-success">+<?php echo e($transaction->amount); ?> USD</span> <!-- Deposit -->
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($transaction->remark ?? 'No remarks'); ?></td> <!-- Display the remark -->
                                        <td><?php echo e($transaction->created_at->format('d M Y h:i A')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                    <!-- Pagination -->
                    <div class="pagination-container">
                    <?php echo e($transactions->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\equity\resources\views\user\transactions.blade.php ENDPATH**/ ?>