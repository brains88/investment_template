<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Header Component -->

<body>
<div class="wrapper">
    <?php echo $__env->make('layout.adminnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- User Navbar -->

    <section class="transaction-history mt-5 pt-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <div class="header-text-full">
                        <h2>Users </h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="table-parent table-responsive">
                        <table class="table table-striped mb-5">
                            <thead>
                                <tr>
                                    <th scope="col">SN</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Mobile</th>
                                    <th scope="col">Joined</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->mobile ?? 'N/A'); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->format('d M Y h:i A')); ?></td>
                                        <td class="d-flex">
                                            <!-- View Button -->
                                            <a href="<?php echo e(route('user.view', $user->id)); ?>" class="btn btn-info" title="View">
                                                <i class="fas fa-eye ml-2"></i>
                                            </a>

                                            <?php if($user->account === 'active'): ?>
                                                <!-- Ban Button -->
                                                <button class="btn btn-warning ml-2" data-bs-toggle="modal" data-bs-target="#banModal<?php echo e($user->id); ?>" title="Ban">
                                                    <i class="fas fa-ban ml-2"></i>
                                                </button>
                                            <?php else: ?>
                                                <!-- Unban Button -->
                                                <form action="<?php echo e(route('user.unban', $user->id)); ?>" method="POST" style="display:inline;" id="banForm<?php echo e($user->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('post'); ?>
                                                    <button type="submit" class="btn btn-success ml-3" id="banButton<?php echo e($user->id); ?>">
                                                        Unban
                                                        <!-- Spinner Icon (Initially Hidden) -->
                                                        <i class="fas fa-spinner fa-spin ml-2 d-none" id="spinner<?php echo e($user->id); ?>"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            <!-- Delete Button -->
                                            <form id="deleteForm<?php echo e($user->id); ?>" action="<?php echo e(route('user.delete', $user->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <!-- Button to trigger modal -->
                                                <button type="button" class="btn btn-danger ml-2" title="Delete" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($user->id); ?>">
                                                    <i class="fas fa-trash ml-2"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>

                                    <!-- Ban Modal -->
                                    <div class="modal fade" id="banModal<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="banModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="banModalLabel">Ban User</h5>
                                                    <button type="button" data-bs-dismiss="modal" class="btn-close" aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(route('user.ban', $user->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="ban_reason" class="form-label">Reason for Banning</label>
                                                            <textarea id="ban_reason" name="ban_reason" class="form-control" required></textarea>
                                                        </div>
                                                    </div>
                                                    <?php if(session('message')): ?>
                                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                            <?php echo e(session('message')); ?>

                                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-warning" id="banButton<?php echo e($user->id); ?>">
                                                            Ban User
                                                            <span class="spinner-border spinner-border-sm d-none" id="spinner<?php echo e($user->id); ?>" role="status" aria-hidden="true"></span>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Delete Modal -->
                                    <div class="modal fade" id="deleteModal<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteModalLabel">Delete User</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    Are you sure you want to delete this user? This action cannot be undone.
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <!-- Delete Button inside modal -->
                                                    <button type="submit" class="btn btn-danger" form="deleteForm<?php echo e($user->id); ?>">Delete</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No users found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <!-- Pagination -->
                        <div class="pagination-container">
                            <?php echo e($users->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
</div>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<script>
    document.querySelectorAll('form[id^="banForm"]').forEach(form => {
        form.addEventListener('submit', function(e) {
            let userId = this.id.replace('banForm', '');
            
            // Disable the button to prevent multiple submissions
            document.getElementById('banButton' + userId).disabled = true;

            // Show the spinner (remove the 'd-none' class)
            let spinner = document.getElementById('spinner' + userId);
            spinner.classList.remove('d-none'); // Make the spinner visible
        });
    });
</script>

<script>
    // Delete confirmation for delete button
    document.querySelectorAll('button[data-bs-toggle="modal"]').forEach(button => {
        button.addEventListener('click', function() {
            let userId = this.closest('form').id.replace('deleteForm', '');
            let deleteForm = document.getElementById('deleteForm' + userId);
            
            // Set the form action dynamically inside the modal
            const formAction = deleteForm.action;
            const modalSubmitButton = document.querySelector(`#deleteModal${userId} .btn-danger`);
            modalSubmitButton.onclick = function() {
                deleteForm.submit();
            };
        });
    });
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\equity\resources\views\admin\users.blade.php ENDPATH**/ ?>