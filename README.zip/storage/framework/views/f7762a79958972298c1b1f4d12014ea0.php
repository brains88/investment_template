<!-- The Tido -->
<script src="//code.tidio.co/8qzi9njq6nkeeus10esgfv7ricxyjadv.js" async></script>
<!-- The end of Tido -->
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/bootstrap/bootstrap.bundle.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/jquery/jquery-3.6.0.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/jquery/jquery-ui.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/plugins/owlcarousel/owl.carousel.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/plugins/counterup/jquery.waypoints.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/plugins/counterup/jquery.counterup.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/plugins/aos/aos.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/plugins/radial-progress/radialprogress.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/js/jquery.flagstrap.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/assets/fontawesome/fontawesome.min.js"></script>


<script src="https://www.equitytradeslc.com/assets/global/js/notiflix-aio-2.7.0.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/global/js/pusher.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/global/js/vue.min.js"></script>
<script src="https://www.equitytradeslc.com/assets/global/js/axios.min.js"></script>
<!-- custom script -->
<script src="https://www.equitytradeslc.com/assets/themes/deepblack/js/script.js"></script>


<script>
    'use strict';

    // dashboard sidebar
    document.getElementById("sidebarCollapse").addEventListener("click", () => {
        document.getElementById("sidebar").classList.toggle("active");
        document.getElementById("content").classList.toggle("active");
    });

    // for datepicker
    $(function () {
        $("#datepicker").datepicker({
            dateFormat: "yy-mm-dd"
        });
        $("#salutation").selectmenu();
    });

            </script>

<?php /**PATH C:\xampp\htdocs\equity\resources\views\layout\footer.blade.php ENDPATH**/ ?>