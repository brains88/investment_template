<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Header Component -->

<body  >
    <div class="wrapper">
      
    <?php echo $__env->make('layout.usernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!------------- others main dashboard body content ------------>
              
<section class="transaction-history mt-5 pt-5">
    <div class="container-fluid">
       <div class="row">
          <div class="col">
             <div class="header-text-full">
                <h2>Referral Bonus</h2>
             </div>
          </div>
       </div>

       <div class="row">
          <div class="col">
             <div class="table-parent table-responsive">
                <table class="table table-striped mb-5">
                    <thead>
                        <tr>
                            <th>SL No.</th>
                            <th>Bonus From</th>
                            <th>Amount</th>
                            <th>Remarks</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($referral->referredUser->username); ?></td>
                <td><?php echo e($referral->referral_bonus); ?> USD</td>
                <td>level 1 Referral bonus From  <?php echo e($referral->referredUser->username); ?></td>
                <td><?php echo e($referral->created_at->format('d M Y')); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5">No referrals found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
    </table>

    <!-- Pagination -->
    <div class="pagination-container text-center">
                            <?php echo e($referrals->links('pagination::bootstrap-4')); ?>

                        </div>
             
             </div>


             </div>
          </div>
       </div>
    </div>
</section>


           </div>
        </div>
    </div>

 <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\equity\resources\views\user\referral-bonus.blade.php ENDPATH**/ ?>