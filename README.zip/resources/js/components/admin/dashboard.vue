<template>
    <h1>Hello Admin</h1>
</template>